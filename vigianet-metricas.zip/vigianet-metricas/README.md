# VigiaNet — Coletor de métricas de servidores

Projeto final de Conectividade em Sistemas Ciberfísicos. Uma pequena empresa pode centralizar as leituras de CPU, memória e disco de seus servidores para identificar uso elevado de recursos e descobrir quando um servidor deixa de enviar dados.

## Integrantes

- Leonardo Bueno de Castilho dos Santos
- João Victor Araújo Lourenço Domingues
- Gabriel Leite Ramon

## Arquitetura

```text
agente-1 ── POST /metrics ──┐
                           ├──► coletor:8080 ──► /data/metrics.jsonl
agente-2 ── POST /metrics ──┘         ▲
                                     │ GET /status
                             computador: 127.0.0.1:8080
```

Os três contêineres Linux se comunicam pela rede bridge `vigianet-demo`. O DNS do Docker resolve o nome `coletor` nessa rede. HTTP sobre TCP permite entregar cada leitura como JSON e receber um código que indica se o servidor aceitou os dados. O coletor usa `ThreadingHTTPServer` para receber vários agentes simultaneamente e um `Lock` para proteger as leituras compartilhadas e o histórico.

O agente usa a biblioteca padrão do Python. Ele calcula o uso de CPU pela diferença entre duas leituras de `/proc/stat`, estima a memória em uso a partir de `MemTotal` e `MemAvailable` em `/proc/meminfo` e usa `shutil.disk_usage("/")` para o disco. No Docker, CPU e memória descrevem o ambiente Linux que fornece `/proc`, e o disco descreve o sistema de arquivos visível em `/`. Os agentes da demonstração compartilham a mesma infraestrutura e podem registrar valores parecidos. Cada agente tem sua própria identificação e envia leituras independentemente.

O coletor valida a identificação e os três percentuais, grava cada leitura aceita em JSON Lines no volume `metrics-data` e mantém a última leitura de cada agente em memória. Depois de 15 segundos sem uma nova leitura, o agente aparece com `active: false`. Se voltar a enviar, aparece ativo novamente. Após reiniciar o coletor, os agentes reaparecem quando enviarem novas leituras, e o histórico permanece no volume.

## Executar

Use Docker com Compose. No Windows, use o Docker Desktop com WSL 2. Se a versão anterior do VigiaNet ainda estiver rodando, encerre seus contêineres antes de usar a porta 8080 nesta versão.

```bash
docker compose up --build -d
docker compose ps
```

Abra `http://127.0.0.1:8080/status`. Depois das primeiras leituras, o JSON deve listar `agente-1` e `agente-2`, com `cpu_percent`, `memory_percent`, `disk_percent`, `received_at` e `active`. Faça uma nova requisição para consultar o estado mais recente.

```bash
docker compose logs --tail=30 coletor agente-1 agente-2
docker compose exec coletor tail -n 5 /data/metrics.jsonl
```

A aplicação roda como o usuário sem privilégios `app`. A porta do coletor é publicada apenas no endereço de loopback da máquina. Os agentes acessam o coletor pela rede interna do projeto.

## Demonstração e evidências

1. Mostre os três serviços com `docker compose ps` e registre IPs, prefixo, gateway e portas usando `docker network inspect vigianet-demo`. Você pode usar `docker compose exec agente-1 ip -br address` e `docker compose exec agente-1 ip route` para conferir os dados dentro do contêiner.
2. Consulte `/status` com os dois agentes ativos e mostre os registros no histórico. Para mostrar a resolução de nome, execute `docker compose exec agente-1 dig coletor A`.
3. Execute `docker compose stop agente-1`. Depois de pelo menos 15 segundos sem leituras desse agente, consulte `/status` novamente. O resultado esperado é `agente-1` inativo e `agente-2` ainda ativo, com novas leituras.
4. Execute `docker compose start agente-1` e consulte `/status` após a próxima leitura. Registre a recuperação observada.
5. Opcionalmente, envie um JSON inválido para conferir a validação. O comando abaixo deve retornar HTTP 400.

```bash
docker compose exec coletor curl -i -H 'Content-Type: application/json' -d '{}' http://127.0.0.1:8080/metrics
```

Registre os resultados obtidos e as evidências no documento-resumo. Para encerrar a demonstração, execute `docker compose down`.

## Declaração de uso de IA generativa

Preencham a declaração conforme o modelo do enunciado, indicando a ferramenta e a versão, o apoio efetivamente recebido e a revisão realizada pela equipe.
