"""Recebe métricas de vários agentes e publica as últimas leituras."""

import json
import logging
import os
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Lock
from time import monotonic


METRICS = ("cpu_percent", "memory_percent", "disk_percent")
STALE_SECONDS = 15


class Collector:
    def __init__(self, log_path):
        self.log_path = Path(log_path)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = Lock()
        self.latest = {}

    def record(self, reading):
        with self.lock:
            entry = {**reading, "received_at": datetime.now(timezone.utc).isoformat()}
            with self.log_path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(entry) + "\n")
            self.latest[entry["agent"]] = (entry, monotonic())

    def status(self):
        with self.lock:
            now = monotonic()
            return [
                {**entry, "active": now - received < STALE_SECONDS}
                for entry, received in self.latest.values()
            ]


class MetricsHandler(BaseHTTPRequestHandler):
    def send_json(self, status, data):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path != "/status":
            self.send_json(404, {"error": "Endpoint não encontrado"})
            return
        self.send_json(200, {"stale_after_seconds": STALE_SECONDS, "agents": self.server.collector.status()})

    def do_POST(self):
        if self.path != "/metrics":
            self.send_json(404, {"error": "Endpoint não encontrado"})
            return
        self.connection.settimeout(3)
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 < size <= 4096:
                raise ValueError("Tamanho de mensagem inválido")
            reading = json.loads(self.rfile.read(size))
            if not isinstance(reading, dict):
                raise ValueError("Envie um objeto JSON")
            agent = reading.get("agent")
            if not isinstance(agent, str) or not 0 < len(agent.strip()) <= 64:
                raise ValueError("Identificação de agente inválida")
            metrics = {name: reading.get(name) for name in METRICS}
            if any(type(value) not in (int, float) or not 0 <= value <= 100 for value in metrics.values()):
                raise ValueError("As três métricas precisam ser números entre 0 e 100")
        except TimeoutError:
            self.send_json(408, {"error": "Tempo de leitura esgotado"})
            return
        except ValueError as error:
            self.send_json(400, {"error": str(error)})
            return

        try:
            self.server.collector.record({"agent": agent, **metrics})
        except OSError:
            logging.exception("Falha ao gravar leitura de %s", agent)
            self.send_json(500, {"error": "Falha ao gravar leitura"})
            return
        self.send_json(201, {"agent": agent})

    def log_message(self, fmt, *args):
        logging.info("http %s - %s", self.address_string(), fmt % args)


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    collector = Collector(os.getenv("LOG_PATH", "data/metrics.jsonl"))
    with ThreadingHTTPServer(("0.0.0.0", 8080), MetricsHandler) as server:
        server.collector = collector
        logging.info("Servidor central ouvindo na porta 8080")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            logging.info("Encerrando servidor central")


if __name__ == "__main__":
    main()
