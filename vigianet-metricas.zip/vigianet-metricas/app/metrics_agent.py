"""Coleta métricas do ambiente Linux e as envia ao servidor central."""

import json
import logging
import os
import shutil
from pathlib import Path
from time import sleep
from urllib.request import Request, urlopen


def cpu_times():
    with Path("/proc/stat").open() as stream:
        values = [int(value) for value in stream.readline().split()[1:9]]
    return sum(values), values[3] + values[4]


def collect_metrics(previous_cpu):
    current_cpu = cpu_times()
    elapsed = current_cpu[0] - previous_cpu[0]
    idle = current_cpu[1] - previous_cpu[1]
    busy = max(0, min(elapsed, elapsed - idle))
    cpu_percent = 100 * busy / elapsed if elapsed > 0 else 0

    memory = {}
    with Path("/proc/meminfo").open() as stream:
        for line in stream:
            name, value = line.split(":", 1)
            if name in {"MemTotal", "MemAvailable"}:
                memory[name] = int(value.split()[0])
    memory_percent = 100 * (1 - memory["MemAvailable"] / memory["MemTotal"])

    disk = shutil.disk_usage("/")
    return {
        "cpu_percent": round(cpu_percent, 2),
        "memory_percent": round(memory_percent, 2),
        "disk_percent": round(100 * disk.used / disk.total, 2),
    }, current_cpu


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    agent_id = os.getenv("AGENT_ID", "agente")
    url = os.getenv("COLLECTOR_URL", "http://127.0.0.1:8080/metrics")
    previous_cpu = cpu_times()
    sleep(0.2)

    while True:
        try:
            metrics, previous_cpu = collect_metrics(previous_cpu)
            request = Request(
                url,
                data=json.dumps({"agent": agent_id, **metrics}).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urlopen(request, timeout=2) as response:
                logging.info("agente=%s HTTP %s métricas=%s", agent_id, response.status, metrics)
        except OSError as error:
            logging.warning("agente=%s falha na coleta ou envio: %s", agent_id, error)
        sleep(5)


if __name__ == "__main__":
    main()
